package com.efigueredo.serviceanotacoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceAnotacoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceAnotacoesApplication.class, args);
	}

}
