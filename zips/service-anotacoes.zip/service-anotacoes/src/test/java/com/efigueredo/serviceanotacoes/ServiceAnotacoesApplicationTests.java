package com.efigueredo.serviceanotacoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceAnotacoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
