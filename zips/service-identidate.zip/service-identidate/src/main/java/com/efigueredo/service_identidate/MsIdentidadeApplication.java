package com.efigueredo.service_identidate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsIdentidadeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsIdentidadeApplication.class, args);
	}

}
