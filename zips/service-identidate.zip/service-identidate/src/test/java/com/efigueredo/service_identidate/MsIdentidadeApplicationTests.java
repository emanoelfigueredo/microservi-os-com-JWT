package com.efigueredo.service_identidate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsIdentidadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
